# WatchSync

Watch videos together in sync — YouTube, Vimeo, Google Drive, direct URLs.

## Project Structure

```
watchsync-fixed/
├── frontend/        ← Vite + React app
│   ├── src/
│   ├── package.json
│   └── vite.config.js
└── backend/         ← Node.js + Express + Socket.IO server
    ├── server.js
    └── package.json
```

## Setup

### Backend

```bash
cd backend
npm install
npm start          # production
# or
npm run dev        # with nodemon auto-reload
```

Runs on `http://localhost:5000` by default.  
Set `PORT` env var to change the port.  
Set `CORS_ORIGIN` env var to your frontend URL in production.

### Frontend

```bash
cd frontend
npm install
npm run dev        # development server on http://localhost:5173
npm run build      # production build → dist/
```

**Environment variable** — create `frontend/.env`:
```
VITE_BACKEND_URL=http://localhost:5000
```
In production, set this to your deployed backend URL.

## Google Drive Videos

1. Upload your video to Google Drive
2. Right-click → **Share** → **Anyone with the link** → **Viewer**
3. Copy the share link and paste it into WatchSync
4. The backend proxy handles streaming and seeking automatically

## Bug Fixes Applied

| # | File | Fix |
|---|------|-----|
| 1 | `src/socket.js` | File was merged into `App.jsx` — separated into its own file |
| 2 | `backend/package.json` | Missing entirely (overwritten by frontend package.json in zip) — recreated |
| 3 | `frontend/vite.config.js` | Missing entirely — created |
| 4 | `server.js` | `app.get` didn't handle `HEAD` requests; browsers send HEAD before GET for video range checks — changed to `app.all` with method guard |
| 5 | `server.js` | OPTIONS preflight handler was registered after GET handler — moved before so Express matches it first |
| 6 | `server.js` | Cache hit always used `method: 'GET'` even for HEAD requests — fixed to forward actual method |
| 7 | `server.js` | `streamResponse` piped body on HEAD requests, violating HTTP spec and stalling connections — added `isHead` guard to send headers-only |
| 8 | `server.js` | `seek_video` handler didn't increment `seekVersion` on the server — added increment so clients receive correct version |
| 9 | `VideoPlayer.jsx` | Host emitted `syncProgress` twice per tick: once via `onProgress` callback and once via `setInterval` — removed socket emit from `onProgress`, kept only the interval |
| 10 | `VideoPlayer.jsx` | GDrive viewer could drag the native seekbar — added transparent pointer-events overlay to block seeking |
| 11 | `VideoPlayer.jsx` | GDrive native `<video>` lacked `controlsList="nodownload"` — added |
| 12 | `RoomContext.jsx` | `sendMessage` built `{ user: currentUser.nickname }` but receivers (and ChatUI) expected `{ nickname: ... }` — fixed field name |
